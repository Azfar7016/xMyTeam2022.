# xMyTeam DDoS
Tools DDoS For Samp,Gtps,Website..
NO GRABBER 100% ,, PASSWORD? xMyTeam2022

# CODED BY AZFAR (Bs/xMyTeam)
